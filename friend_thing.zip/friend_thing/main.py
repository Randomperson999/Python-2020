import Friends
Friends.Bestie.chat("Hi there")
Friends.Bestie.chat("Can you give me a ride?")
Friends.Bestie.chat("Call and let me know")
Friends.Bestie.chat("Are you awake?")
